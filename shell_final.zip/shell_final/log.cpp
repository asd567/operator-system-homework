#include "log.h"
#include <iostream>
#include <string.h>
using namespace std;

_node * init(_node * h)
{
	h->next = NULL;
	return h;
}
void display(_node * h)
{
	_node *p = new _node; 
	p = h->next;	//头结点不存命令
	//cout<<p->cmd<<endl;
	while(p->next!=NULL)
	{
		cout<<p->cmd<<" ";
		p=p->next;
	}
	cout<<p->cmd<<endl;//因为单链表的最后一个指针存有内容，而指向的下一个为空
	//delete(p);
}
void push(_node * h,char *item)
{
	_node * p = new _node;
	_node * q = h;
	//_node * temp = new _node;
	//char* qcmd=NULL;
	p->cmd = item;//将新的命令存储到新开辟的结构体空间中
	p->next = NULL;
	cout << p->cmd << " is item"<<endl;
	//由于结构体指针是由h指向头结点（栈尾），要把新的存储空间放到栈中，需要找到栈顶（即链表尾）
	while(q->next!=NULL)
	{
		q = q->next;
	}
	q->next = p;//此时不能将p节点delete掉
	//display(h);
	/*if(q->cmd!=NULL){
		if(h->cmd==NULL){
			cout<<"h:NULL"<<endl;
		}else{
			cout<<"h:"<<h->cmd<<endl;
		}
		cout<<"q->next->cmd:"<<q->next->cmd<<endl;
		cout<<"q->cmd:"<<q->cmd<<endl;
	}*/
	//cout<<"q->next->cmd:"<<q->next->cmd<<endl;
	//cout<<"q->cmd:"<<q->cmd<<endl;
}

