#ifndef _mv_
#define _mv_
int mymv(int ac,char *av1,char *av2);
#endif
