#include<stdio.h>
#include<unistd.h>
#include<sys/stat.h>
#include<string.h>
#include<stdlib.h>
#include<sys/types.h>
#include<fcntl.h>
/*
int getSuffix(char* fName1,char* fName2){
	char *ptr1,*ptr2;
	ptr1=strrchr(fName1,'.');
	ptr2=strrchr(fName2,'.');
	if(ptr1 == NULL && ptr2 == NULL){
		return 1;
	}
	else if(strcmp(ptr1,ptr2)==0){
		return 1;
	}else{
		return 0;
	}
}*/

int mymv(int ac,char *av1,char *av2){
	struct stat st1;//定义一个stat类型的变量，以后作为stat()的传入参数
	struct stat st2;//同上
	if(ac!=4){//判断在执行mv命令时传入的参数格式是否正确
		printf("输入参数不正确\n");
		return 0;
	}
	if(stat(av1,&st1)==0 && stat(av2,&st2)==-1){//判断第二个输入参数是不是已存在的目录或文件,如果不是已经存在的文件或者目录就执行重命名操作
		printf("重命名\n");
		if(rename(av1,av2)==-1){//rename函数进行重命名操作，将av1重命名为av2，如果返回值为-1，就失败，0成功
                	printf("error!\n");
			exit(1);
        	}else{
			printf("Rename successfully.\n");
		}
	}
	if(stat(av1,&st1)==0&&stat(av2,&st2)==0&&S_ISDIR(st2.st_mode)&&S_ISREG(st1.st_mode)){//前两个条件判断两个输入的参数是不是都已经存在的文件或者目录，第三个条件判断输入的av1是不是一个文件，第四个条件判断输入的av2是不是一个目录。如果以上条件都满足就可以进行下面的移动文件的操作。

//移动文件操作的整个过程就是先在av2指定的目录下创建一个和av1同名的文件，再使用输入输出流将av1文件中的内容读出，然后写入到在av2目录下创建的新文件当中。然后再删除av1文件就完事了
		printf("移动文件\n");
		char readPath[100],writePath[100];//存储读文件和写文件的路径
		char originalPath[100];//这个变量用来储存进行文件移动操作之前的路径。因为在进行文件移动时会改变当前的工作路径，所以我们需要在进行完所有操作之后回到刚开始进行所有操作之前的工作路径。
		getcwd(originalPath,sizeof(originalPath));//获取当前的工作路径，并将这个路径存入originalPath中
		getcwd(readPath,sizeof(readPath));//先获取当前的工作路径，存入readPath中，以便后续拼接读文件的路径
		//printf("originalPath:%s\n",originalPath);
		strcat(readPath,"/");//在readPath中存储的字符串的最后拼接一个"/"，这样做是为了以后拼接路径的正确
		strcat(readPath,av1);//将传入的av1,也就是要读取的文件拼接到读文件路径的最后，这样就构成了最终的读文件的路径
		char dirPath[100];
		strcat(dirPath,av2);//将传入的av2存入dirPath中
		//printf("dirPath:%s\n",dirPath);
		if(chdir(dirPath)==0){//将当前的工作路径移动到移动文件的目标地址，如果成功就返回0
			//printf("***************\n");
			open(av1,O_RDWR | O_CREAT, S_IRWXU | S_IRWXG | S_IRWXO);//在当前目录下创建一个与av1同名的文件，open函数中的几个参数分别表示如果不存在该文件就创建；以可写可读模式创建该文件
			getcwd(writePath,sizeof(writePath));//获取当前的工作路径存入写文件路径中，当前的工作路径还没有到刚刚创建的这个文件中，所以我们需要得到刚刚创建的这个文件的路径
			strcat(writePath,"/");
			strcat(writePath,av1);//将刚创建的文件的名字拼接到写文件的路径中，这样就得到了最终的写文件的路径
			//printf("readPath:%s\n",readPath);
			//printf("writePath:%s\n",writePath);
			FILE* readFile=fopen(readPath,"r");//创建一个输入流用于读出readPath文件的内容
			FILE* writeFile=fopen(writePath,"w");//创建一个输出流用于将内容写入writePath文件
			char ch;//这个字符用来存储每次读出的一个字符
			if(NULL==writeFile){//如果输入流创建不成功就输出错误并结束程序
				perror("writeFile is NULL");
			}
			if(NULL==readFile){//如果输出流创建不成功就输出错误并结束程序
				perror("readFile is NULL");
			}
			while((ch=fgetc(readFile))!=EOF)//fgetc()函数每次从readPath文件中读取一个字符并存入ch中，如果返回值为EOF说明已经全部读完了
			fputc(ch,writeFile);//将读出的ch存入writeFile文件中
			fclose(readFile);//完成读操作之后关闭输出流
			fclose(writeFile);//完成写操作之后关闭输入流
			readFile=NULL;
			writeFile=NULL;
		}else{//如果找不到移动文件的目标地址的话就报错
			printf("你输入的目录不存在\n");
			return 0;
		}
		int ret;
		//printf("originalPath:%s\n",originalPath);
		ret=chdir(originalPath);//完成读写操作之后当前的工作路径还停留在被写入的文件的路径下(也就是writePath路径)，所以需要返回到刚开始的工作路径，这个路径已经被存到originalPath中，所以就可以很容易的转到出事路径
		if(ret==0){
			//printf("返回原路径成功\n");
			remove(av1);//返回到初始路径后找到av1文件并删除
		}
	}
	return 1;
}
