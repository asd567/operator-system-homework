#include <stdio.h>
#include <stdlib.h>
#include <utmp.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#define FILE_PATH "/var/run/utmp"
#define SHOWHOST


void show_info(struct utmp *utbufp);  //显示一条记录的函数

int getwho()
{
	struct utmp  current_record;
	FILE *utmpfd = NULL;		
	//打开登录信息记录文件
	if((utmpfd = fopen(FILE_PATH,"r"))==NULL)
	{
		printf("Error\n");
		return 0;
	}
	memset(&current_record,0,sizeof(current_record));
	while(fread(&current_record,sizeof(char),sizeof(current_record),utmpfd)==sizeof(current_record)) 
	{  
		show_info(&current_record); 
		memset(&current_record,0,sizeof(current_record));
	}  
	fclose(utmpfd);//关闭文件


	return 1;
}

void show_info(struct utmp *utmpfp)
{
	time_t time_long = utmpfp->ut_time;//时间转换
	struct tm*local_now=localtime(&time_long);
	if(utmpfp->ut_type == USER_PROCESS)
	{ 
		printf("%8s\t",utmpfp->ut_name); 
		printf("%12s\t",utmpfp->ut_line); 
		printf("%d-%d-%d %d:%d ",
			local_now->tm_year+1900,local_now->tm_mon+1,
			local_now->tm_mday,local_now->tm_hour,local_now->tm_min); //登录时间 
		printf("(%s)",utmpfp->ut_host);//登录主机名
		printf("\n"); 
	}


}
