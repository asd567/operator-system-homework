#ifndef _rmdir_
#define _rmdir_
int my_rmdir(char * s);
#endif
