#ifndef _pwd_
#define _pwd_
int get_inode(char *path);
void get_name_inode(char name[], int inode,int buflen);
void do_pwd(char *path);
int mypwd();
#endif
