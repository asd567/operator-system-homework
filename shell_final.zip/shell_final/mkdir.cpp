#include <iostream>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
using namespace std;
int mkdir(char *s)
{
	int errno;
	errno = mkdir(s,00700);
	if(errno !=0 )
	{
		cout<<"Error"<<endl;
		return 0;
	}
	return 1;
}
