/*************************************************************************
	> File Name: mycp.h
	> Author: ma6174
	> Mail: ma6174@163.com 
	> Created Time: Mon 12 Nov 2018 06:28:53 AM PST
 ************************************************************************/

#ifndef _mycp_
#define _mycp_
int mycpfile( char * pSrc,char *pDes);
#endif
