/*************************************************************************
	> File Name: main.cpp
	> Author: ma6174
	> Mail: ma6174@163.com 
	> Created Time: 2018年11月05日 星期一 11时37分41秒
 ************************************************************************/

#include <iostream>
#include <string.h>
#include "log.h"
#include "shell.h"

int main(int argc,char* argv[]) 
{
	_node *h = new _node;
	prefix(); //显示路径
    	size_t len=0;
    	char* buffer=NULL;
	init(h);//初始化
    	while(getline(&buffer,&len,stdin)!=-1)
	{
		//cout<<buffer<<endl;//显示命令
        	buffer[strlen(buffer)-1]='\0';//末位设置为0
	//	cout << "push "<< buffer<<endl;
		push(h,buffer);//将命令进入命令栈
	//	display(h);
        	if(!execute(buffer,h))
		{
        	    break;
		}
        	prefix();//打印显示路径和提示符
        	free(buffer);//释放内存
        	buffer=NULL;
        }
    	if(buffer!=NULL)//意外终止的处理
    	{
		free(buffer);
    	    	buffer=NULL;
    	}
    	//销毁内存栈
	
	if(h->next == NULL)
		return 0;
	while(h->next!=NULL)
	{
		_node *p = new _node;
		p = h;
		h = h->next;
		delete(p);
	}
	delete(h);
    	return 0;
}

