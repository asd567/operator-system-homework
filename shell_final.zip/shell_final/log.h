#ifndef _log_h
#define _log_h
struct _node{
	char* cmd;
	 _node * next;

};
//_node *h;
_node* init(_node*h);
void  destory(_node*h);
void  push(_node*h,char*item);
void display(_node*h);
#endif
