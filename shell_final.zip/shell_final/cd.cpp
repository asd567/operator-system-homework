#include<stdio.h>
#include<errno.h>
#include<sys/types.h>
#include<unistd.h>
#include<string.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<pwd.h>
#include <stdlib.h>
#define NUM 1024
#define SIZE 50

int  mystrtok(char *argv[],char *string);

//对字符串进行分割，把命令分割开，用到了字符串的分割函数
int mystrtok(char *argv[],char *string)
{
	int i=0;
	char delim[]="/";
 	char *p;
 	argv[0]=strtok(string,delim);//字符串分割函数的使用	
	/*char* strtok (char* str,constchar* delimiters );
	str：在第一次被调用的时间str是传入需要被切割字符串的首地址；在后面调用的时间传入NULL
	delimiters：表示切割字符串（字符串中每个字符都会 当作分割符)
	当s中的字符查找到末尾时，返回NULL; 
	如果查不到delimiter所标示的字符，则返回当前strtok的字符串的指针*/
	while(argv[i]!=NULL)
	{
		argv[++i]=strtok(NULL,delim);
 		//printf("%s is %d\n",argv[i],i);
	}
	/*for(int j=0;j<=i;j++)
	{
		if(strcmp(argv[j],point)==0){
			for(int x=j+1;x<=i;x++){
				printf("/%s",argv[x]);
			}
			break;
		}
	}*/
	return i;
}

//获得一个命令提示符的字符串
char *getusername(char buffer[NUM])
{
	uid_t userid;//uid_t在stat结构中是文件所有者参数st_uid的数据类型
	char *username;
 	char *hostname;
 	char *ptr,*p;
	char buf1[1024],buf2[1024];
	char *argv[NUM];
	int len=0;			
	getcwd(buf2,sizeof(buf2));//getcwd()会将当前工作目录的绝对路径复制到参数buffer所指的内存空间中,参数size为buf的空间大小。 
	username=getenv("USER");//调用getenv函数，来获得shell命令的提示中的用户名
	strcpy(buffer,username);//char *strcpy(char* dest, const char *src)：用src覆盖dest
	strcat(buffer,"@");//char *strcat(char *dest, const char *src):把src拼接到dest后面
	gethostname(buf1,sizeof(buf1));//调用此函数来获取shell命令的提示中的主机名
	//p=strtok(buf1,delim);//对主机进行截取
	strcat(buffer,buf1);//字符串的连接函数
	len=mystrtok(argv,buf2);
	//printf("%s",argv[1]);
	ptr=strrchr(buf2,'/');//字符串的从后往前进行截取的函数，将多的shell命令提示中的路径.字符串的从后往前进行截取的函数，将多的shell命令提示中的路径
	/*strrchr():找一个字符c在另一个字符串str中末次出现的位置（也就是从str的右侧开始查找字符c首次出现的位置），并返回从字符串中的这个位置起，一直到字符串结束的所有字符。如果未能找到指定字符，那么函数将返回NULL。*/
	if(strcmp(ptr,"/")==0)
	/*strcmp()函数是根据ACSII码的值来比较两个字符串的；strcmp()函数首先将s1字符串的第一个字符值减去s2第一个字符，若差值为零则继续比较下去；若差值不为零，则返回差值。若s1、s2字符串相等，则返回零；若s1大于s2，则返回大于零的数；否则，则返回小于零的数。*/
	{
		ptr="/";
	}
	else if(strcmp(ptr,"~")==0)
	{
		ptr="~";
	}
	else
	{
		ptr=strtok(ptr,"/");
	}
	//把获得的用户名@主机名  路径]连接在一起
	strcat(buffer,":~");
	for(int a=2;a<len;a++){
		strcat(buffer,argv[a]);
		strcat(buffer,"/");
	}
	//strcat(buffer,ptr);
	return buffer;
}

int main()
{
	pid_t pid;
	 int status;
	 char *argv[NUM];
	 char buffer[NUM];
	 char str[NUM];
	 int j=-1;
	 char *string=NULL;
	 string=getenv("USER");//getenv函数：获取当前环境变量，里面的参数不分大小写

	 //当前用户是root用户还是普通用户,通过字符串的比较，如果是root，则返回0；
	 //user是环境变量，值为用户名，root用户值为root
	if((strcmp(string,"root"))==0)
	{
		j=0;
	}
	while(1)//循环输出当前路径，这个功能可以收到perfix()函数中，写的很走心
	{
		//通过调用上面自定义的getusername（）函数，来得到shell命令中的提示
		printf("[%s]",getusername(buffer));
		//判断是使用root的提示#，还是其他用户的$
		
		if(j==0)
		{
			printf("#");
		}
		else{
			printf("$");
		}
		//字符串的输入，要用gets函数或者用fgets函数，因为scanf函数把空格看成字符串的结束
		gets("%s",str);//gets()函数从标准输入（键盘）读入一行数据，所谓读取一行，就是遇到换行符就返回。
		//调用字符串的分割函数，获得要截取出来的命令和命令参数，例如：ls -a分别放到argv[0],argv[1]中
		if(strcmp(str,"exit")==0){
			exit(0);
		}
		status=mystrtok(argv,str);
		/*for(int i=0;i<status;i++){
			printf("%s",argv[i]);	
		}*/
		char path[100];//将当前工作的局对路径放到path变量下，大小为path大小
		getcwd(path,sizeof(path));
		if(str[0]!='/'){//将两个char类型合并
			strcat(path,"/");//返回path所指向的指针，要求path足够大能容得下
		}
		strcat(path,str);
		//printf("%s",path);
		status=chdir(path);
		if(status!=0)
		{
			printf("输入路径格式不正确\n");
		}else{
			//printf("[%s]",getusername(buffer));
		}
		/*
		//通过fork（）函数来创建一个父进程和一个子进程
		pid=fork();
		if(-1==pid){
			printf("your fork failed!\n");
		}
		else if(pid==0)
		{
			//子进程用来对shell命令进程进程解释执行的
			if(argv[1]!=NULL)
			{
				execvp(argv[0],argv);//execvp()会从PATH 环境变量所指的目录中查找符合参数file 的文件名, 找到后便执行该文件, 然后将第二个参数argv 传给该欲执行的文件。
			}
			else if(argv[1]==NULL)
			{
				execlp(argv[0],argv[0],NULL,NULL);//int execlp(const char *file, const char *arg, ... , (char  *) NULL );   其中第一个参数file指向可执行文件名称，因为execlp()函数会从系统PATH路径中寻找相应命令，所以不需要带完整路径；第二个参数之后就都是传给可执行文件的参数，类似main函数的args[]，只是最后一个参数必须为空字符指针；
			}
		}
		else{
			//父进程用来等待子进程的结束，然后再循环输入shell命令
			if(wait(&status)==-1)
			// wait()函数用于使父进程（也就是调用wait()的进程）阻塞，直到一个子进程结束或者该进程接收到了一个指定的信号为止。如果该父进程没有子进程或者它的子进程已经结束，则wait()函数就会立即返回。
			{
				printf("wait failed!\n");
				exit(1);
			}
		}*/
	}
	return 0;
}
