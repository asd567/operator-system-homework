/*************************************************************************
	> File Name: shell.h
	> Author: ma6174
	> Mail: ma6174@163.com 
	> Created Time: 2018年11月05日 星期一 11时23分52秒
 ************************************************************************/
#include "log.h"
#include <iostream>
using namespace std;
//开始shell
void prefix();//打印路径
int execute(char*buffer,_node*h);//执行命令
void substr(char dst[],char src[],int start,int end);//截取子字符串
