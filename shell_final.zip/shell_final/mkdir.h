#ifndef _mkdir_
#define _mkdir_

int mkdir(char *s);

#endif
