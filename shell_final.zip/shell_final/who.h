#ifndef _who_
#define _who_
void show_info(struct utmp *utbufp);
int getwho();
#endif
