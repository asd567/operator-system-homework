/*************************************************************************
	> File Name: shell.cpp
	> Author: ma6174
	> Mail: ma6174@163.com 
	> Created Time: 2018年11月05日 星期一 11时27分09秒
 ************************************************************************/

#include <iostream>
#include <cstring>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
//因为shell.cpp要调用各种函数，所以要把所有实现的命令的头文件加入进来
#include "log.h"
#include "shell.h"
#include "myls1.h"
#include "date.h"
#include "mkdir.h"
#include "who.h"
#include "rmdir.h"
#include "mymv.h"
#include "mypwd.h"
#include "mycp.h"

#define MAXLEN 1000//假定当前路径最字符数为1000
#define MAX_LEN 1000
using namespace std;
void  split(char * buffer)//调用该函数，说明已经知道是cd xxx 命令
{

	char * ss = NULL;
	int len = strlen(buffer);
	char *dir = new char[len];
	dir[0]='/';
	for(int i=3; i<len; i++)
	{
		dir[i-2] = buffer[i];
	}
	ss = dir;
	char present[MAX_LEN];//获取当前工作目录的指针
	getcwd(present,MAX_LEN);
	strcat(present,ss);//将/xxx和当前工作目录拼接起来，新环境在present
	ss = present;
	
	if(chdir(ss)!=0)
	{
		cout<<"change dir error"<<endl;
	}
}
void prefix()//该函数作用：获取当前工作目录
{
	//要通过环境变量进行查看当前用户为普通用户还是root用户，
	//方法：用getenv(value)函数
	char x;//用于存储最后一位提示符，&或者#
	char *s;
	s = getenv("USER");
	if(strcmp(s,"root") == 0)
	{
		x = '#';//超级用户
	}else
	{
		x = '$';//普通用户
	}
	char buffer[MAXLEN];//存放当前工作路径
	getcwd(buffer,MAXLEN);//getcwd()该函数作用是获取当前工作路径
	cout<<">>>"<<buffer<<"~"<<x<<" ";//懒的拼接
}
int execute(char*buffer,_node*h)//对命令进行选择
{ 
	int err;
	//push(h,buffer);//将命令进入命令栈
		
	//og_push(l,buffer);
	if(strncmp(buffer,"mv",2) == 0){
		int index=0;
		char *argv[10];
		char *delim=" ";
		char *element;
		element=strtok(buffer,delim);
		argv[index]=element;
		index++;
		while(element!=NULL){
			element=strtok(NULL,delim);
			argv[index++]=element;
		}
		//cout<<index<<endl;
		//cout<<argv[1]<<endl;
		//cout<<argv[2]<<endl;
		err = mymv(index,argv[1],argv[2]);
		if(err!=1){
			cout<<"mv false"<<endl;
			return 0;
		}else{
			return 1;
		}
	}
	//如果是 cd xx 命令，改变当前工作目录
	if(strncmp(buffer,"cd",2) == 0)//比较前两个字符，如果是cd 的话
	{
		//截取xxx和把/xxx拼接到当前路径下面，并改变当前目录
		split(buffer);
		return 1;
	}
	if(strcmp(buffer,"!#")==0)//展示历史命令
	{
		display(h);
		return 1;
	}
	if(strcmp(buffer,"exit") == 0)//退出shell的命令
		return 0;
	if(strcmp(buffer,"ls")==0)
	{
		err = myls();
		if(err!=1)
		{
			cout<<"ls false"<<endl;
			return 0;
		}else
		{
			return 1;
		}
	}
	if(strcmp(buffer,"date")==0)
	{
		err = getDate();
		if(err!=1)
		{
			cout<<"date false"<<endl;
			return 0;
		}else
		{
			return 1;
		}
	}
	if(strcmp(buffer,"who") == 0)
	{
		err = getwho();
		if(err!=1)
		{
			cout<<"who false"<<endl;
			return 0;
		}else
		{
			return 1;
		}
	}
	if(strncmp(buffer,"cp",2)==0)
	{
                char dir[200];
		char diir[200];
		size_t len1 = 0;
		size_t len2 = 0;
		cin.getline(dir,200);
		
		cin.getline(diir,200);
		err=mycpfile(dir,diir);
		
		if(err!=1)
		{
			cout<<"cp false"<<endl;
			return 0;
		}else
		{
			cout<<"sourse file:";
			
                        
			return 1;
		} 
	}
	//判断buffer前5个字符是否是mkdir
	int len = strlen(buffer);
	if(strncmp(buffer,"mkdir",5)==0)//比较buffer中的前5位是否是mkdir
	{
		char * dir= new char[len-6];
		for(int i=6; i<len; i++)
		{
			dir[i-6] = buffer[i];
		}
		err = mkdir(dir);
		if(err!=1)
		{
			cout<<"mkdir false"<<endl;
			return 0;
		}else
		{
			return 1;
		}
	}
	if(strncmp(buffer,"rmdir",5)==0)
	{
		char * dir = new char[len-6];
		for(int i=6; i<len; i++)
		{
			dir[i-6] = buffer[i];
		}
		err = my_rmdir(dir);
		cout<<1<<endl;
		if(err == 1)
		{
			return 1;
		}
		
	}
	if(strcmp(buffer,"pwd") == 0)
	{
		mypwd();
		return 1;
	}
	cout<<"no such commend"<<endl;
	return 1;
}
