#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<sys/stat.h>
#include<dirent.h>
#include<stdlib.h>
#include<errno.h>

//输入文件名，获得文件的节点号
int get_inode(char *path)
{
     struct stat info;
     int inode;
     if(stat(path,&info)==-1){
          perror("get inode error");
          exit(errno);
     }
     inode = info.st_ino;//stat.st_ino:inode节点号
     return inode;
}

//根据节点号获取文件名，并拼接路径
void get_name_inode(char name[], int inode,int buflen)
{
     DIR *dir_ptr;
     struct dirent *ptr;
     dir_ptr = opendir(".");
     if(dir_ptr == NULL){
          perror("dir open error");
          exit(errno);
     }
     while((ptr = readdir(dir_ptr))!=NULL){
          if(ptr->d_ino==inode){
               strcpy(name,ptr->d_name);//d_name:文件名
               closedir(dir_ptr);
          }
     }
}

char* do_pwd(char *path)
{
     char name[BUFSIZ];
     int inode=get_inode(path);
     if(inode!=get_inode("..")){
          chdir("..");
          get_name_inode(name,inode,BUFSIZ);
          do_pwd(".");                       //递归查找，直到根目录返回
	  printf("/%s",name);
     }
}

int mypwd()
{
	char path[BUFSIZ];
	getcwd(path,sizeof(path));
     do_pwd(".");
     printf("\n");
	chdir(path);
     return 1;
}
