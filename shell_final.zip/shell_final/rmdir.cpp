#include <iostream>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
using namespace std;
int my_rmdir(char * s)
{	
	int errno;
	errno = rmdir(s);
	if(errno !=0 )
	{
		cout<<"delete error"<<endl;
		return 0;
	}
	return 1;
}

